package com.project1.datacenter.distribution;


import co.paralleluniverse.fibers.SuspendExecution;
import desmoj.core.simulator.Model;
import desmoj.core.simulator.SimProcess;
import desmoj.core.simulator.TimeSpan;

public class DataCenter extends SimProcess {


	private Simulation myModel;
	
	public DataCenter(Model owner, String name, boolean showInTrace) {

		super(owner, name, showInTrace);
		myModel = (Simulation)owner;
	}

	public void lifeCycle() throws SuspendExecution {
		while (true) {
			if (myModel.requestQueue.isEmpty()) {
				myModel.idleDCQueue.insert(this);
				passivate();
			} else {
				Request nextRequest = myModel.requestQueue.first();
				myModel.requestQueue.remove(nextRequest);
				nextRequest.endWait();
				
				double t = myModel.getServiceTime();
				nextRequest.setServiceTime(t);
				hold(new TimeSpan(t));
				nextRequest.activate(new TimeSpan(0));
			}
		}
	}
}
