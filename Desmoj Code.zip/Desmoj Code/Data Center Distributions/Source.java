package com.project1.datacenter.distribution;

import co.paralleluniverse.fibers.SuspendExecution;
import desmoj.core.simulator.Model;
import desmoj.core.simulator.SimProcess;
import desmoj.core.simulator.TimeSpan;

public class Source extends SimProcess {

	private Simulation myModel;
	
	public Source(Model owner, String name, boolean showInTrace) {
		super(owner, name, showInTrace);
		
		myModel = (Simulation) owner;
	}
	/**
	 * describes this process's life cycle: continually generate new requests.
	 */
	public void lifeCycle() throws SuspendExecution {

		// get a reference to the model
		//Simulation model = (Simulation)getModel();

		// endless loop:
		int index = 0;
		while (true) {

			Request request = new Request(myModel, "Request"+index, true );
			request.activate(new TimeSpan(0)); //activateAfter(this);

			TimeSpan arrivals = myModel.getRequestArrivalTime();
			Singleton sgt = Singleton.getInstance();
			sgt.setTotalArrivals(arrivals.getTimeAsDouble());
			hold(arrivals); //new TimeSpan(arrivals));

			index++;
		}
	}
}
