package com.project1.datacenter.distribution;

import desmoj.core.dist.ContDistExponential;
import desmoj.core.dist.DiscreteDistPoisson;
import desmoj.core.simulator.Experiment;
import desmoj.core.simulator.Model;
import desmoj.core.simulator.ProcessQueue;
import desmoj.core.simulator.TimeInstant;
import desmoj.core.simulator.TimeSpan;


public class Simulation extends Model {

	protected static int NUM_DC = 50;
	protected static long TOTAL_TIME = 10000000L;
	protected static double SERVICE_MEAN = 200.0;
	protected static double ARRIVAL_RATE = 5.0;
	/*
	 * Full Cap: 1000 sec
	 * 10% = 10000
	 * 20% = 5000
	 * 30% = 10000.0/3.0
	 */
	
	/*
	 * Max: 25
	 */
	

	private desmoj.core.dist.ContDistExponential requestArrivalTime;

	private desmoj.core.dist.ContDistExponential serviceTime;

	protected desmoj.core.simulator.ProcessQueue<Request> requestQueue;

	protected desmoj.core.simulator.ProcessQueue<DataCenter> idleDCQueue;


	public Simulation(Model owner, String modelName, boolean showInReport, boolean showInTrace) {
		super(owner, modelName, showInReport, showInTrace);
	}

	public String description() {
		return "This model describes a data center queueing system.";
	}

	public void doInitialSchedules() {

		for (int i=0; i < NUM_DC; i++)
		{
			DataCenter dataCenter = new DataCenter(this, "Data Center", true);
			dataCenter.activate(new TimeSpan(0.0));
		}

		Source generator = new Source(this,"RequestArrival",false);
		generator.activate(new TimeSpan(0.0));
	}

	public void init() {
		
		serviceTime= new ContDistExponential(this, "ServiceTimeStream", SERVICE_MEAN, true, false);
		serviceTime.setNonNegative(true);

		requestArrivalTime= new ContDistExponential(this, "RequestArrivalTimeStream", ARRIVAL_RATE, true, false);
		requestArrivalTime.setNonNegative(true);
		
		requestQueue = new ProcessQueue<Request>(this, "Request Queue", true, false);

		idleDCQueue = new ProcessQueue<DataCenter>(this, "idle DC Queue", true, false);
	}

	public double getServiceTime() {
		return serviceTime.sample();
	}

	public TimeSpan getRequestArrivalTime() {
		return requestArrivalTime.sampleTimeSpan();
	}

	public static void main(java.lang.String[] args) {
		
		Experiment.setEpsilon(java.util.concurrent.TimeUnit.MILLISECONDS);
		Experiment.setReferenceUnit(java.util.concurrent.TimeUnit.MILLISECONDS);
		Experiment exp = new Experiment("Distribution");

		Simulation model = new Simulation(null, "ProcessesExample", true, false);
		
		model.connectToExperiment(exp);

		exp.setShowProgressBar(true);  // display a progress bar (or not)
		exp.stop(new TimeInstant(TOTAL_TIME));   // set end of simulation at 
		exp.tracePeriod(new TimeInstant(0), new TimeInstant(10000000));  // set the period of the trace
		exp.debugPeriod(new TimeInstant(0), new TimeInstant(10000000));   // and debug output
		
		exp.start();

		exp.report();

		exp.finish();
		
		Singleton sgt = Singleton.getInstance();
		sgt.averageTime();
		sgt.findProbability();  
		sgt.export();
		
		
	}
} 
