package com.project1.datacenter.distribution;

import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Set;

public class Singleton {
	protected static int NUM_DC = 50;
	protected static int TOTAL_TIME = (int) (100000);
	protected static int SERVICE_MEAN = 200;
	protected static double ARRIVAL_RATE = 	2000.0/1.0;
	protected static String fileName = "PD-W1-50.txt";
	
	private static Singleton singleton;
	private static Hashtable<Double, Double> table;
	
	private double totalWaitTime;
	private double totalServiceTime;
	private double totalTime;
	private long totalNumRequest;
	private double totalArrivals;
	
	private Singleton() {
		table = new Hashtable<Double, Double>();
		totalWaitTime = 0.0;
		totalServiceTime = 0.0;
		totalTime = 0.0;
		totalNumRequest = 0L;
		totalArrivals = 0.0;
	}
	
	public static Singleton getInstance()
	{
		if (singleton == null)
			singleton = new Singleton();
		return singleton;
	}
	
	public void export()
	{
		try {
			PrintWriter pw = new PrintWriter(fileName, "UTF-8");
			Set<Double> set = table.keySet();
			pw.println("2 Sources");
			pw.println("4 Data Centers");
			pw.println("Servers " + NUM_DC);
			pw.println("Total Time " +TOTAL_TIME);
			pw.println("Service Mean " + SERVICE_MEAN);
			pw.println("Arrival Rate " + ARRIVAL_RATE);
			for (Double key : set) {
				//System.out.println(key + " " + table.get(key));
				pw.println(key + " " + table.get(key));
			}
			pw.close();
			//System.out.println("++" + totalNumRequest + ", " + totalWaitTime + ", " + totalServiceTime + ", " + totalTime + ", " + totalArrivals);
		} catch(Exception e) {
		}
	}
	
	public void addCount(Double key) {
		Double total = table.get(key);
		if(total == null)
			table.put(key, (double) 1);
		else  {
			total = total + 1;
			table.put(key, total);
		}
	}
	
	public void findProbability()
	{
		//System.out.println("before:" + table.size());
		double totalNumber = 0;
		Set<Double> set1 = table.keySet();
		for(Double key : set1)
			totalNumber += table.get(key);
		double j = 0;
		
		Set<Double> set = table.keySet();
		for(Double key : set) {
			j = table.get(key);
			j = (j*100 / totalNumber) / 100;
			table.put(key, j);
		}
		//System.out.println("after:" + table.size());
	}
	public void averageTime() {
		double counter = 0; double total = 0;
		Set<Double> set = table.keySet();
		for(Double key : set) {
			//if (table.get(key) == null) {
			//	System.out.println("null found!!!!!!!!!!!!!!!!");
			//}
			counter += table.get(key);
			total += key * table.get(key);
		}
		//System.out.println("Total: " + total + ", counter=" + counter);
		total = total / counter;
		System.out.println(total);
	}

	public void setTotals(double tTime, double tWaitTime, double tServiceTime, long tNumRequest) {
		this.totalTime += tTime;
		this.totalWaitTime += tWaitTime;
		this.totalServiceTime += tServiceTime;
		this.totalNumRequest += tNumRequest;
	}

	public void setTotalArrivals(double t) {
		this.totalArrivals += t;
	}
}
