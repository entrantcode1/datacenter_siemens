package com.project1.datacenter.distribution;

import co.paralleluniverse.fibers.SuspendExecution;
import desmoj.core.simulator.Model;
import desmoj.core.simulator.SimProcess;
import desmoj.core.simulator.TimeInstant;
import desmoj.core.simulator.TimeOperations;
import desmoj.core.simulator.TimeSpan;

public class Request extends SimProcess {

	private Simulation myModel;
	private double serviceTime;
	private double totalTime;
	private long totalNumRequest;
	private TimeInstant waitStart;
	private TimeInstant waitEnd;

	public Request(Model owner, String name, boolean showInTrace) {

		super(owner, name, showInTrace);
		totalTime = 0.0;
		serviceTime = 0.0;
		totalNumRequest = 0L;
		// store a reference to the model this request is associated with
		myModel = (Simulation)owner;
	}
	public double getServiceTime()
	{
		return serviceTime;
	}
	public double getTotalTime()
	{
		return totalTime;
	}
	public void setServiceTime(double time)
	{
		serviceTime = time;
	}
	public void setTimeStart(TimeInstant time)
	{
		waitStart = time;
	}
	public void setTimeEnd(TimeInstant time)
	{
		waitEnd = time;
	}
	public void addTotalTime(double time)
	{
		totalTime = totalTime + time;
	}
	
	
	public void lifeCycle() throws SuspendExecution {
		myModel.requestQueue.insert(this);
		waitStart = presentTime();		
		sendTraceNote("RequestQueuelength: "+ myModel.requestQueue.length());

		if (!myModel.idleDCQueue.isEmpty()) {
			DataCenter dataCenter = myModel.idleDCQueue.first();
			myModel.idleDCQueue.remove(dataCenter);
			
			dataCenter.activate(new TimeSpan(0)); //activateAfter(this);

		}
		passivate();
		
		if(waitStart != null && waitEnd != null) {
			double wait = TimeOperations.diff(waitStart, waitEnd).getTimeAsDouble();
			totalTime += wait;
		}
		totalTime += serviceTime;
		totalNumRequest++;
		
		
		//double round = totalTime/1000.0;
		double round = totalTime;
		round = Math.round(round * 100.0) / 100.0;
		//if(round >= 3)
		//	round = 3;
		Singleton sgt = Singleton.getInstance();
		sgt.addCount(round);
		}
	
	public void endWait() {
		waitEnd = presentTime();
	}
	public void startWait() {
		waitStart = presentTime();
	}
} 
 