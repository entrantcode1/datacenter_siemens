
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Set;

public class Singleton {

	private static final Integer TOTAL_RUN_TIME = 10000000;
	private static final int TOTAL_REQUEST_NUM = 8000;
	
	private static Singleton singleton;
	private static Hashtable<Double, Double> table;
	private static Hashtable<Integer, Integer> tableDataCenterRequestNumber;
	private static int[][] requestsP;
	private static int counterP=0;
	
	private Singleton() {
		table = new Hashtable<Double, Double>();
		tableDataCenterRequestNumber = new Hashtable<Integer, Integer>();
		requestsP = new int [TOTAL_REQUEST_NUM][3];
	}
	
	public static Singleton getInstance()
	{
		if (singleton == null)
			singleton = new Singleton();
		return singleton;
	}
	public void addRequestP(int source, int dest, int ID) {
		
		for(int j=0; j<requestsP.length; j++) {
			if((requestsP[j][0]==source && requestsP[j][2]==ID)) {
				//System.out.println("counterP " +counterP);
				return;
			}
			//else if(requestsP[j][0] == 0) {
			//	System.out.println("counterP "+counterP);
			//	break;
			//}
		}
		System.out.println("-----" +counterP);
		requestsP[counterP][0] = source;
		requestsP[counterP][1] = dest;
		requestsP[counterP][2] = ID;
		counterP++;
		return;
	}
	public void exportTable()
	{
		Set<Double> set = table.keySet();
		for (Double key : set) {
			System.out.println(key + ", " + table.get(key));
		}
	}
	public void exportDataCenter()
	{
		System.out.println("Data Center, Number of Requests Processed");
		Set<Integer> set = tableDataCenterRequestNumber.keySet();
		for (Integer key : set) {
			System.out.println(key + ", " + tableDataCenterRequestNumber.get(key));
		}
	}
	public void exportDataCenterRates() 
	{
		System.out.println("Data Center, Request Arrival Rate");
		Set<Integer> set = tableDataCenterRequestNumber.keySet();
		for(Integer key : set) {
			System.out.println(key + ", " + ((double)tableDataCenterRequestNumber.get(key) / (double)TOTAL_RUN_TIME));
		}
	}
	
	public void addCount(Double key) {
		Double total = table.get(key);
		if(total == null)
			table.put(key, (double) 1);
		else  {
			total = total + 1;
			table.put(key, total);
		}
	}
	
	public void addDataCenterProcessed(Integer key) {
		Integer total = tableDataCenterRequestNumber.get(key);
		if(total == null)
			tableDataCenterRequestNumber.put(key, 1);
		else {
			total = total + 1;
			tableDataCenterRequestNumber.put(key, total);
		}
	}
	public void findProbability()
	{
		double totalNumber = 0;
		Set<Double> set1 = table.keySet();
		for(Double key : set1)
			totalNumber += table.get(key);
		double j = 0;
		
		Set<Double> set = table.keySet();
		for(Double key : set) {
			j = table.get(key);
			j = (j*100 / totalNumber) / 100;
			table.put(key, j);
		}
	}
	
	
	public void exportSLA_P() {
		//int d1 = 0; int d2 = 0; int d3 = 0; int d4 = 0;
		int s1 = 0; int s2 = 0;
		
		for(int j=0; j<requestsP.length; j++) {
			if(requestsP[j][0] == 0)
				break;
			else if(requestsP[j][0] == 1)
				s1++;
			else if(requestsP[j][0] == 2)
				s2++;
			//else if(requestsP[j][1] == 3)
			//	d3++;
			//else if(requestsP[j][1] == 4)
			//	d4++;
		}
		
		double percent = 0;
		Set<Integer> set = tableDataCenterRequestNumber.keySet();
		for (Integer key : set) {
			switch(key) {
			/*case 1: percent = 100.0 - 100.0 * d1 / tableDataCenterRequestNumber.get(key);
				System.out.println("1: " +percent);
				break;
			case 2: percent = 100.0 - 100.0 * d2 / tableDataCenterRequestNumber.get(key);
				System.out.println("2: " +percent);
				break;	
			case 3: percent = 100.0 - 100.0 * d3 / tableDataCenterRequestNumber.get(key);
				System.out.println("3: " +percent);
				break;	
			case 4: percent = 100.0 - 100.0 * d4 / tableDataCenterRequestNumber.get(key);
				System.out.println("4: " +percent);
				break;	
			}*/
			case 1: percent = 100.0 - 100.0 * s1 / tableDataCenterRequestNumber.get(key);
				System.out.println("1: " +percent);
				break;
			case 2: percent = 100.0 - 100.0 * s2 / tableDataCenterRequestNumber.get(key);
				System.out.println("2: " +percent);
				break;
			}
				
		}		
	}
}
