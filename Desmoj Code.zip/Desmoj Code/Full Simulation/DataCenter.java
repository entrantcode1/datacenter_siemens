
import co.paralleluniverse.fibers.SuspendExecution;
import desmoj.core.simulator.Model;
import desmoj.core.simulator.SimProcess;
import desmoj.core.simulator.TimeInstant;
import desmoj.core.simulator.TimeSpan;

public class DataCenter extends SimProcess {

	private Simulation myModel;
	private int ID;
	private int totalRequests = 0;
	
	public DataCenter(Model owner, String name, boolean showInTrace, int id) {
		super(owner, name, showInTrace);
		myModel = (Simulation)owner;
		ID = id;
	}
	public int getTotalRequests() {
		return totalRequests;
	}
	
	
	public void lifeCycle() throws SuspendExecution {
		Singleton sgt = Singleton.getInstance();
		switch (ID) {
		case 1: {
			while (true) {
				if (myModel.requestQueue1.isEmpty()) {
					myModel.idleDCQueue1.insert(this);
					passivate();
				}
				else {
					Request nextRequest = myModel.requestQueue1.first();
					myModel.requestQueue1.remove(nextRequest);
					TimeInstant t2 = myModel.presentTime();
					nextRequest.setTimeEnd(t2.getTimeAsDouble() );
					double t = myModel.getServiceTime();
					nextRequest.setServiceTime(t);
					hold(new TimeSpan(nextRequest.getServiceTime()) );
					nextRequest.activate(new TimeSpan(0));
					totalRequests++;
					sgt.addDataCenterProcessed(nextRequest.getSource());  
				}
			}
		}
		case 2: {
			while (true) {
				if (myModel.requestQueue2.isEmpty()) {
					myModel.idleDCQueue2.insert(this);
					passivate();
				}
				else {
					Request nextRequest = myModel.requestQueue2.first();
					myModel.requestQueue2.remove(nextRequest);
					TimeInstant t2 = myModel.presentTime();
					nextRequest.setTimeEnd(t2.getTimeAsDouble() );
					double t = myModel.getServiceTime();
					nextRequest.setServiceTime(t);
					hold(new TimeSpan(nextRequest.getServiceTime()) );
					nextRequest.activate(new TimeSpan(0));
					totalRequests++;
					sgt.addDataCenterProcessed(nextRequest.getSource()); 
				}
			}
		}
		case 3: {
			while (true) {
				if (myModel.requestQueue3.isEmpty()) {
					myModel.idleDCQueue3.insert(this);
					passivate();
				}
				else {
					Request nextRequest = myModel.requestQueue3.first();
					myModel.requestQueue3.remove(nextRequest);
					TimeInstant t2 = myModel.presentTime();
					nextRequest.setTimeEnd(t2.getTimeAsDouble() );
					double t = myModel.getServiceTime();
					nextRequest.setServiceTime(t);
					hold(new TimeSpan(nextRequest.getServiceTime()) );
					nextRequest.activate(new TimeSpan(0));
					totalRequests++;
					sgt.addDataCenterProcessed(nextRequest.getSource()); 
				}
			}
		}
		case 4: {
			while (true) {
				if (myModel.requestQueue4.isEmpty()) {
					myModel.idleDCQueue4.insert(this);
					passivate();
				}
				else {
					Request nextRequest = myModel.requestQueue4.first();
					myModel.requestQueue4.remove(nextRequest);
					TimeInstant t2 = myModel.presentTime();
					nextRequest.setTimeEnd(t2.getTimeAsDouble() );
					double t = myModel.getServiceTime();
					nextRequest.setServiceTime(t);
					hold(new TimeSpan(nextRequest.getServiceTime()) );
					nextRequest.activate(new TimeSpan(0));
					totalRequests++;
					sgt.addDataCenterProcessed(nextRequest.getSource()); 
				}
			}
		}
	}
	}
} 
