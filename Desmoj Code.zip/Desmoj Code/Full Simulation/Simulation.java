

import java.util.concurrent.TimeUnit;

import desmoj.core.dist.ContDistExponential;
import desmoj.core.dist.ContDistNormal;
import desmoj.core.dist.DiscreteDistPoisson;
import desmoj.core.simulator.Experiment;
import desmoj.core.simulator.Model;
import desmoj.core.simulator.ProcessQueue;
import desmoj.core.simulator.TimeInstant;
import desmoj.core.simulator.TimeSpan;

public class Simulation extends Model {

	protected static int NUM_DC = 1;
	protected static int TOTAL_RUN_TIME = 1000000;
	
	protected static double ARRIVAL1 = 1000.0/1.8707;
	protected static double ARRIVAL2 = 1000.0/1.0223;	
	
	//protected static double ARRIVAL1 = 1000.0/1.7545;
	//protected static double ARRIVAL2 = 1000.0/1.1997;
	
	
	protected static double SERVICE_MEAN = 200.0;
	
	private desmoj.core.dist.ContDistExponential requestArrivalTime1;
	private desmoj.core.dist.ContDistExponential requestArrivalTime2;
	
	private desmoj.core.dist.ContDistExponential serviceTime;
	
	//  Chile (Source)	
	private desmoj.core.dist.ContDistNormal path11; // Oregon (Data Center)
	private desmoj.core.dist.ContDistNormal path12; // North Carolina
	private desmoj.core.dist.ContDistNormal path13; // Beijing
	private desmoj.core.dist.ContDistNormal path14; // Hong Kong
	// Sydney
	private desmoj.core.dist.ContDistNormal path21;
	private desmoj.core.dist.ContDistNormal path22;
	private desmoj.core.dist.ContDistNormal path23;
	private desmoj.core.dist.ContDistNormal path24;

	protected desmoj.core.simulator.ProcessQueue<Request> sourceQueue1;
	protected desmoj.core.simulator.ProcessQueue<Request> sourceQueue2;

	
	protected desmoj.core.simulator.ProcessQueue<Request> requestQueue1;
	protected desmoj.core.simulator.ProcessQueue<Request> requestQueue2;
	protected desmoj.core.simulator.ProcessQueue<Request> requestQueue3;
	protected desmoj.core.simulator.ProcessQueue<Request> requestQueue4;

	protected desmoj.core.simulator.ProcessQueue<DataCenter> idleDCQueue1;
	protected desmoj.core.simulator.ProcessQueue<DataCenter> idleDCQueue2;
	protected desmoj.core.simulator.ProcessQueue<DataCenter> idleDCQueue3;
	protected desmoj.core.simulator.ProcessQueue<DataCenter> idleDCQueue4;

	
	public Simulation(Model owner, String modelName, boolean showInReport, boolean showInTrace) {
		super(owner, modelName, showInReport, showInTrace);
	}

	public String description() {
		return "This model describes a data center queueing system.";
	}

	public void doInitialSchedules() {

		// create and activate the van carrier(s)
		for (int i=0; i < NUM_DC; i++) {
			DataCenter dataCenter = new DataCenter(this, "Data_Center_1", true, 1);
			dataCenter.activate(new TimeSpan(0.0));
		}
		for (int i=0; i < NUM_DC; i++) {
			DataCenter dataCenter = new DataCenter(this, "Data_Center_2", true, 2);
			dataCenter.activate(new TimeSpan(0.0));
		}
		for (int i=0; i < NUM_DC; i++) {
			DataCenter dataCenter = new DataCenter(this, "Data_Center_3", true, 3);
			dataCenter.activate(new TimeSpan(0.0));
		}
		for (int i=0; i < NUM_DC; i++) {
			DataCenter dataCenter = new DataCenter(this, "Data_Center_4", true, 4);
			dataCenter.activate(new TimeSpan(0.0));
		}

		for(int j = 1; j <= 2; j++) {
			Source generator = new Source(this,"RequestArrival", false, j);
			generator.activate(new TimeSpan(0.0));
		}
	}

	public void init() {
		
		serviceTime = new ContDistExponential(this, "ServiceTimeStream", SERVICE_MEAN, true, false);
		serviceTime.setNonNegative(true);

		requestArrivalTime1 = new ContDistExponential(this, "RequestArrivalTimeStream", ARRIVAL1, true, false);
		requestArrivalTime1.setNonNegative(true);
		requestArrivalTime2 = new ContDistExponential(this, "RequestArrivalTimeStream", ARRIVAL2, true, false);
		requestArrivalTime2.setNonNegative(true);
		
		path11 = new ContDistNormal(this, "Network11", 91.0, 1.0, true, false);
		path12 = new ContDistNormal(this, "Network12", 68.0, 1.0, true, false);
		path13 = new ContDistNormal(this, "Network13", 179.0, 1.0, true, false);
		path14 = new ContDistNormal(this, "Network14", 187.0, 1.0, true, false);
		
		path21 = new ContDistNormal(this, "Network21", 119.0, 1.0, true, false);
		path22 = new ContDistNormal(this, "Network22", 149.0, 1.0, true, false);
		path23 = new ContDistNormal(this, "Network23", 86.0, 1.0, true, false);
		path24 = new ContDistNormal(this, "Network24", 71.0, 1.0, true, false);
		
		sourceQueue1 = new ProcessQueue<Request>(this, "Source Queue 1", true, true);
		sourceQueue2 = new ProcessQueue<Request>(this, "Source Queue 2", true, true);
		
		requestQueue1 = new ProcessQueue<Request>(this, "Request Queue 1", true, true);
		requestQueue2 = new ProcessQueue<Request>(this, "Request Queue 2", true, true);
		requestQueue3 = new ProcessQueue<Request>(this, "Request Queue 3", true, true);
		requestQueue4 = new ProcessQueue<Request>(this, "Request Queue 4", true, true);

		idleDCQueue1 = new ProcessQueue<DataCenter>(this, "idle DC Queue 1", true, true);
		idleDCQueue2 = new ProcessQueue<DataCenter>(this, "idle DC Queue 2", true, true);
		idleDCQueue3 = new ProcessQueue<DataCenter>(this, "idle DC Queue 3", true, true);
		idleDCQueue4 = new ProcessQueue<DataCenter>(this, "idle DC Queue 4", true, true);
	}

	public double getServiceTime() {
		return serviceTime.sample();
	}
	public double getRequestArrivalTime1() {
		return requestArrivalTime1.sample();
	}
	public double getRequestArrivalTime2() {
		return requestArrivalTime2.sample();
	}
	
	public double getNetwork11() {
		return Math.abs(path11.sample());
	}
	public double getNetwork12() {
		return Math.abs(path12.sample());
	}
	public double getNetwork13() {
		return Math.abs(path13.sample());
	}
	public double getNetwork14() {
		return Math.abs(path14.sample());
	}
	public double getNetwork21() {
		return Math.abs(path21.sample());
	}
	public double getNetwork22() {
		return Math.abs(path22.sample());
	}
	public double getNetwork23() {
		return Math.abs(path23.sample());
	}
	public double getNetwork24() {
		return Math.abs(path24.sample());
	}

	
	public static void main(java.lang.String[] args) {
		Experiment.setEpsilon(TimeUnit.MILLISECONDS);
		Experiment.setReferenceUnit(TimeUnit.MILLISECONDS);
		
		Simulation model = new Simulation(null, "ProcessesExample", true, true);
		
 	    Experiment exp = new Experiment("DataCenterExperiment");

		model.connectToExperiment(exp);

		// set experiment parameters
		exp.setShowProgressBar(true);  // display a progress bar (or not)
		exp.stop(new TimeInstant(TOTAL_RUN_TIME, TimeUnit.MILLISECONDS));   // set end of simulation at 
		exp.tracePeriod(new TimeInstant(0), new TimeInstant(10000, TimeUnit.MILLISECONDS));  // set the period of the trace
		exp.debugPeriod(new TimeInstant(0), new TimeInstant(100000, TimeUnit.MILLISECONDS));   // and debug output
		
		exp.start();

		exp.report();
		System.out.println("sdfkjdslkfdslkfdsjl");
		exp.finish();
		System.out.println("dkfsjd;lfkjsdl;fksjdf");
		Singleton sgt = Singleton.getInstance();
		sgt.exportDataCenter();
		sgt.exportDataCenterRates();
		sgt.exportSLA_P();
//		sgt.findProbability(6250);  
//		sgt.export();
		}
} 
