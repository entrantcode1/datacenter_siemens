import java.util.concurrent.ThreadLocalRandom;

import co.paralleluniverse.fibers.SuspendExecution;
import desmoj.core.simulator.Model;
import desmoj.core.simulator.SimProcess;
import desmoj.core.simulator.TimeSpan;

public class Source extends SimProcess {
	
	private Simulation myModel;
	private int sourceID;
	public Source(Model owner, String name, boolean showInTrace, int id) {
		super(owner, name, showInTrace);
		sourceID = id;
		myModel = (Simulation) owner;
	}
	public void lifeCycle() throws SuspendExecution {
		int lambda1, lambda2 = 0;
		
		int P1 = 22;
		int P2 = 62;
		double sTime = 0;
		int IDcreator = 0;
		switch (sourceID) {
			case 1: {
				while (true) {
					int rand1 = 0; int rand2 = 0;
					sTime = myModel.getServiceTime();
					rand1 = ThreadLocalRandom.current().nextInt(1, 100 + 1);
					rand2 = ThreadLocalRandom.current().nextInt(1, 100 + 1);
					
					if(rand1 <= P1 )
						lambda1 = 1;
					else lambda1 = 2;
					if(rand2 <= P2 )
						lambda2 = 3;
					else lambda2 = 4;
					Request request1 = new Request(myModel, "Request 1.1", true, IDcreator, sourceID, lambda1, sTime);
					Request request2 = new Request(myModel, "Request 1.2", true, IDcreator, sourceID, lambda2, sTime);
					request1.activate();
					request2.activate();
					IDcreator++;
					hold(new TimeSpan(myModel.getRequestArrivalTime1()));
				}
			}
			case 2: {
				while (true) {
					int rand1 = 0; int rand2 = 0;
					sTime = myModel.getServiceTime();
					rand1 = ThreadLocalRandom.current().nextInt(1, 100 + 1);
					rand2 = ThreadLocalRandom.current().nextInt(1, 100 + 1);
					
					if(rand1 <= P1)
						lambda1 = 1;
					else lambda1 = 2;
					if(rand2 <= P2 )
						lambda2 = 3;
					else lambda2 = 4;
					Request request1 = new Request(myModel, "Request 2.1", true, IDcreator, sourceID, lambda1, sTime);
					Request request2 = new Request(myModel, "Request 2.2", true, IDcreator, sourceID, lambda2, sTime);
					request1.activate();
					request2.activate();
					IDcreator++;
					hold(new TimeSpan(myModel.getRequestArrivalTime2()));				}
			}
		}
	}
} 
