
import co.paralleluniverse.fibers.SuspendExecution;
import desmoj.core.simulator.Model;
import desmoj.core.simulator.SimProcess;
import desmoj.core.simulator.TimeInstant;
import desmoj.core.simulator.TimeSpan;

public class Request extends SimProcess {

	private static final double SLA = 1.25;
	
	private Simulation myModel;
	
	private int ID;
	
	private double serviceTime = 0;
	private double networkTime = 0;
	private double totalTime = 0;
	private double timeStart = 0;
	private double timeEnd = 0;
	
	private int source;
	private int destination;

	public Request(Model owner, String name, boolean showInTrace, int id, int sour, int dest, double sTime) {
		super(owner, name, showInTrace);
		myModel = (Simulation)owner;
		ID = id;
		source = sour;
		destination = dest;
		serviceTime = sTime;
	}
	
	public double getServiceTime()
	{
		return serviceTime;
	}
	public double getTotalTime()
	{
		return totalTime;
	}
	public double getTimeStart()
	{
		return timeStart;
	}
	public double getTimeEnd()
	{
		return timeEnd;
	}
	public double getNetworkTime()
	{
		return networkTime;
	}
	public void setNetworkTime(int source, int destination)
	{
		if(source == 1 && destination == 1)
			networkTime = myModel.getNetwork11();
		else if(source == 1 && destination == 2)
			networkTime = myModel.getNetwork12();
		else if(source == 1 && destination == 3)
			networkTime = myModel.getNetwork13();
		else if(source == 1 && destination == 4)
			networkTime = myModel.getNetwork14();
		else if(source == 2 && destination == 1)
			networkTime = myModel.getNetwork21();
		else if(source == 2 && destination == 2)
			networkTime = myModel.getNetwork22();
		else if(source == 2 && destination == 3)
			networkTime = myModel.getNetwork23();
		else if(source == 2 && destination == 4)
			networkTime = myModel.getNetwork24();
		
	}
	public void setTimeStart(double time)
	{
		timeStart = time;
	}
	public void setTimeEnd(double time)
	{
		timeEnd = time;
	}
	public void setServiceTime(double time) {
		serviceTime = time;
	}
	public void addTotalTime(double time)
	{
		totalTime = totalTime + time;
	}
	public void setDCNumber(int num)
	{
		destination = num;
	}
	public int getSource() {
		return source;
	}
	

	public void lifeCycle() throws SuspendExecution {
		switch (destination) {
		case 1: {setNetworkTime(source, destination); hold(new TimeSpan(getNetworkTime())); myModel.requestQueue1.insert(this); break;}
		case 2: {setNetworkTime(source, destination); hold(new TimeSpan(getNetworkTime())); myModel.requestQueue2.insert(this); break;}
		case 3: {setNetworkTime(source, destination); hold(new TimeSpan(getNetworkTime())); myModel.requestQueue3.insert(this); break;}
		case 4: {setNetworkTime(source, destination); hold(new TimeSpan(getNetworkTime())); myModel.requestQueue4.insert(this); break;}
		}
 		
		TimeInstant t1 = myModel.presentTime();
		this.setTimeStart(t1.getTimeAsDouble() );
		
		switch (destination) {
			case 1: {
				if (!myModel.idleDCQueue1.isEmpty()) {
					DataCenter dataCenter = myModel.idleDCQueue1.first();
					myModel.idleDCQueue1.remove(dataCenter);
					dataCenter.activateAfter(this);
					passivate(); break;
				} else {
					passivate(); break;
				}
			}
			case 2: {
				if (!myModel.idleDCQueue2.isEmpty()) {
					DataCenter dataCenter = myModel.idleDCQueue2.first();
					myModel.idleDCQueue2.remove(dataCenter);
					dataCenter.activateAfter(this);
					passivate(); break;
				} else {
					passivate(); break;
				}
			}
			case 3: {
				if (!myModel.idleDCQueue3.isEmpty()) {
					DataCenter dataCenter = myModel.idleDCQueue3.first();
					myModel.idleDCQueue3.remove(dataCenter);
					dataCenter.activateAfter(this);
					passivate(); break;
				} else {
					passivate(); break;
				}
			}
			case 4: {
				if (!myModel.idleDCQueue4.isEmpty()) {
					DataCenter dataCenter = myModel.idleDCQueue4.first();
					myModel.idleDCQueue4.remove(dataCenter);
					dataCenter.activateAfter(this);
					passivate(); break;
				} else {
					passivate(); break;
				}
			}
		}
	
			totalTime += timeEnd - timeStart ;
			totalTime += serviceTime;
			totalTime += Math.round(networkTime * 100.0) / 100.0;
			double round = totalTime/1000.0;
			round = Math.round(round * 100.0) / 100.0;
			Singleton sgt = Singleton.getInstance();

			if(round > SLA) {
				sgt.addRequestP(source, destination, ID);
			}
			sgt.addCount(round);  
	}
} 
