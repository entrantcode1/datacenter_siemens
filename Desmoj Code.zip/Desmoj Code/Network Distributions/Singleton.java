package desmoj.tutorial1.ProcessesExample;

import java.io.PrintWriter;
import java.util.Hashtable;
import java.util.Set;

public class Singleton {

	private static Singleton singleton;
	private static Hashtable<Double, Double> table;

	private Singleton() {
		table = new Hashtable<Double, Double>();
	}

	public static Singleton getInstance()
	{
		if (singleton == null)
			singleton = new Singleton();
		return singleton;
	}
	
	public void export()
	{
		try {
			PrintWriter pw = new PrintWriter("PN-S2-D4.txt", "UTF-8");
			Set<Double> set = table.keySet();
			pw.println("2 Sources");
			pw.println("4 Data Centers");
			pw.println("Source 2");
			pw.println("Destination 4");
			for (Double key : set) {
				System.out.println(key + " " + table.get(key));
				pw.println(key + " " + table.get(key));
			}
			pw.close();
		} catch(Exception e) {
			
		}
	}
	
	public void addCount(Double key) {
		Double total = table.get(key);
		if(total == null)
			table.put(key, (double) 1);
		else  {
			total = total + 1;
			table.put(key, total);
		}
	}
	
	public void findProbability(double totalRequests)
	{
		double j = 0;
		Set<Double> set = table.keySet();
		for(Double key : set) {
			j = table.get(key);
			j = (j*1000 / totalRequests) / 1000;
			table.put(key, j);
		}
	}
}
