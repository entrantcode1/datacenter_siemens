package desmoj.tutorial1.ProcessesExample;

import desmoj.core.dist.ContDistNormal;
import desmoj.core.simulator.Experiment;
import desmoj.core.simulator.Model;
import desmoj.core.simulator.TimeInstant;
import desmoj.core.simulator.TimeSpan;


public class SimulationNetworkLatency extends Model {

	private desmoj.core.dist.ContDistNormal Time;

	public SimulationNetworkLatency(Model owner, String modelName, boolean showInReport, boolean showInTrace) {
		super(owner, modelName, showInReport, showInTrace);
	}

	public String description() {
		return "This model describes a data center queueing system.";
	}

	public void doInitialSchedules() {

		Source generator = new Source(this,"RequestArrival",false);
		generator.activate(new TimeSpan(0.0));
	}

	public void init() {
		
		// initalising the serviceTimeStream
		// Parameters:
		// this                = belongs to this model
		// "ServiceTimeStream" = the name of the stream
		// 1.0                 = mean time to process
		// true                = show in report?
		// false               = show in trace?
		Time= new ContDistNormal(this, "times", 71.0, 1.0, true, false);
	}

	public double getTime() {
		return Math.abs(Time.sample());
	}

	public static void main(java.lang.String[] args) {
		Experiment exp = new Experiment("ProcessExperiment");

		SimulationNetworkLatency model = new SimulationNetworkLatency(null, "ProcessesExample", true, false);
		
		model.connectToExperiment(exp);

		// set experiment parameters
		exp.setShowProgressBar(true);  // display a progress bar (or not)
		exp.stop(new TimeInstant(10000000));   // set end of simulation at 
		
		exp.start();	
		exp.report();
		exp.finish();
		
		Singleton sgt = Singleton.getInstance();
		sgt.findProbability(10000000);  // divide by total number of requests
		sgt.export();
		}
} 
