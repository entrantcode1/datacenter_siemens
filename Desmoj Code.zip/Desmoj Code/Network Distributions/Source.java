package desmoj.tutorial1.ProcessesExample;

import co.paralleluniverse.fibers.SuspendExecution;
import desmoj.core.simulator.Model;
import desmoj.core.simulator.SimProcess;

public class Source extends SimProcess {

	/**
	 * RequestGenerator constructor comment.
	 * @param owner the model this request generator belongs to
	 * @param name this request generator's name
	 * @param showInTrace flag to indicate if this process shall produce output for the trace
	 */
	
	private SimulationNetworkLatency myModel;
	
	public Source(Model owner, String name, boolean showInTrace) {
		super(owner, name, showInTrace);
		
		myModel = (SimulationNetworkLatency) owner;
	}

	public void lifeCycle() throws SuspendExecution {
		double round = 0;
		for(int counter = 0; counter < 10000000; counter++) {
			round = myModel.getTime();
			Singleton sgt = Singleton.getInstance();
			round = round/1000.0;
			round = Math.round(round * 100.0 ) / 100.0;
			sgt.addCount(round);  
		}
	}
} /* end of process class */
