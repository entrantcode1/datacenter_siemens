function[] = dispDCWork()

x = [0.1597    0.1994    0.9590    0.5526    0.1809    0.1030    0.4894    0.2490];

d1 = x(1) + x(2) + x(5) + x(6);
d2 = x(3) + x(4) + x(7) + x(8);
d3 = x(1) + x(3) + x(5) + x(7);
d4 = x(2) + x(4) + x(6) + x(8);
    
s1 = x(1) + x(2) + x(3) + x(4);
s2 = x(5) + x(6) + x(7) + x(8);

disp(d1);
disp(d2);
disp(d3);
disp(d4);

disp(s1);
disp(s2);

end