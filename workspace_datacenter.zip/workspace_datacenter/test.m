function [c] = test()
    c = [];
    x = [0.25,0.25,0.25,0.25,0.25,0.25,0.25,0.25];

    totalLoad = [0.6,0.6];
    DCcap = [2,2,2,2];
    threshhold = 30;
    Data = importdata('AllData3.mat');
    sum=0;
        
    for c=1:threshhold
        sum = sum+Data(c,2,1,workload(x,DCcap(1)));
    end
    P11 = sum;
    sum = 0;
    disp(P11);    

    for c=1:threshhold
        sum = sum+Data(c,2,2,workload(x,DCcap(2)));
    end
    P12 = sum;
    sum = 0;
    disp(P12);
    
    for c=1:threshhold
        sum = sum+Data(c,2,3,workload(x,DCcap(3)));
    end
    P13 = sum;
    sum = 0;
    disp(P13);
    
    for c=1:threshhold
        sum = sum+Data(c,2,4,workload(x,DCcap(4)));
    end
    P14 = sum;
    sum = 0;
    disp(P14);

    for c=1:threshhold
        sum = sum+Data(c,2,5,workload(x,DCcap(1)));
    end
    P21 = sum;
    sum = 0;
    disp(P21);
    
    for c=1:threshhold
        sum = sum+Data(c,2,6,workload(x,DCcap(2)));
    end
    P22 = sum;
    sum = 0;
    disp(P22);
    
    for c=1:threshhold
        sum = sum+Data(c,2,7,workload(x,DCcap(3)));
    end
    P23 = sum;
    sum = 0;
    disp(P23);
    
    for c=1:threshhold
        sum = sum+Data(c,2,8,workload(x,DCcap(4)));
    end
    P24 = sum;
    disp(P24);
    
    c(1) = 0.95-(1.0/totalLoad(1))*(x(1)*P11*P13+x(2)*P11*P14+x(3)*P12*P13+x(4)*P12*P14);
    c(2) = 0.95-(1.0/totalLoad(2))*(x(5)*P21*P23+x(6)*P21*P24+x(7)*P22*P23+x(8)*P22*P24);
    
end
    