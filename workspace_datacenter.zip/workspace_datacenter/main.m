clc;
clear;

timeSlot = 1;

totalSource1 = 3.5*importdata('workloadSource1.mat');
totalSource2 = 3.5*importdata('workloadSource2.mat');
Data = importdata('AllData4.mat');

eStatic = [0.3,0.3,0.3,0.3];
compPower = [6,6,6,6];
ePrice1 = importdata('ePrice1.mat');
ePrice2 = importdata('ePrice2.mat');
ePrice3 = importdata('ePrice3.mat');
ePrice4 = importdata('ePrice4.mat');

PUE = [1.11, 1.16, 1.13, 1.5];
waterCoef = 0.05;
WUE = [0.02, 0.12 ,0.197, 0.015];
EWIF = [3.1, 0.98, 1.2, 1.5];

R = [0, 0, 0, 0];
serverCap = [5,5,5,5];

Ytotal = [0,0,0,0];
X = [0,0,0,0];

Ytotal(1) = compPower(1)*((ePrice1(timeSlot)*PUE(1)+waterCoef*(WUE(1)+EWIF(1,1)*PUE(1)))) / serverCap(1);
Ytotal(2) = compPower(2)*((ePrice2(timeSlot)*PUE(2)+waterCoef*(WUE(2)+EWIF(1,2)*PUE(2)))) / serverCap(2);
Ytotal(3) = compPower(3)*((ePrice3(timeSlot)*PUE(3)+waterCoef*(WUE(3)+EWIF(1,3)*PUE(3)))) / serverCap(3);
Ytotal(4) = compPower(4)*((ePrice4(timeSlot)*PUE(4)+waterCoef*(WUE(4)+EWIF(1,4)*PUE(4)))) / serverCap(4);

A=[]; b = [];


Aeq = [1.0 1.0 1.0 1.0 0.0 0.0 0.0 0.0; ...
       0.0 0.0 0.0 0.0 1.0 1.0 1.0 1.0];
beq = [totalSource1(timeSlot); totalSource2(timeSlot)];

lb = [0.0,0.0,0.0,0.0,0.0,0.0,0.0,0.0];
ub=[2.5,2.5,2.5,2.5,2.5,2.5,2.5,2.5];
x0 = rand([1,8]);
nonlincon = @nlcon;

x = fmincon(@(x) ...
    + Ytotal(1)*x(1)/x(9) + Ytotal(1)*x(2)/x(9) + Ytotal(1)*x(5)/x(9) + Ytotal(1)*x(6)/x(9) ...
    + Ytotal(2)*x(3)/x(10) + Ytotal(2)*x(4)/x(10) + Ytotal(2)*x(7)/x(10) + Ytotal(2)*x(8)/x(10) ...
    + Ytotal(3)*x(1)/x(11) + Ytotal(3)*x(3)/x(11) + Ytotal(3)*x(5)/x(11) + Ytotal(3)*x(7)/x(11) ...
    + Ytotal(4)*x(2)/x(12) + Ytotal(4)*x(4)/x(12) + Ytotal(4)*x(6)/x(12) + Ytotal(4)*x(8)/x(12), ...
    x0, A, b, Aeq, beq, lb, ub, nonlincon);
%disp('lambdas');
disp(x);
X(1,1) = x(9)*eStatic(1)*(ePrice1(timeSlot)*PUE(1) + waterCoef*(WUE(1,1)+EWIF(1,1)*PUE(1,1))) - R(1,1)*(ePrice1(timeSlot)+waterCoef*EWIF(1));
X(1,2) = x(10)*eStatic(2)*(ePrice2(timeSlot)*PUE(2) + waterCoef*(WUE(1,2)+EWIF(1,2)*PUE(1,2))) - R(1,2)*(ePrice2(timeSlot)+waterCoef*EWIF(2));
X(1,3) = x(11)*eStatic(3)*(ePrice3(timeSlot)*PUE(3) + waterCoef*(WUE(1,3)+EWIF(1,3)*PUE(1,3))) - R(1,3)*(ePrice3(timeSlot)+waterCoef*EWIF(3));
X(1,4) = x(12)*eStatic(4)*(ePrice4(timeSlot)*PUE(4) + waterCoef*(WUE(1,4)+EWIF(1,4)*PUE(1,4))) - R(1,4)*(ePrice4(timeSlot)+waterCoef*EWIF(4));



Answer = (sum(X)...
    + Ytotal(1,1)*x(1) + Ytotal(1,1)*x(2) + Ytotal(1)*x(5) + Ytotal(1,1)*x(6) ...
    + Ytotal(1,2)*x(3) + Ytotal(1,2)*x(4) + Ytotal(2)*x(7) + Ytotal(1,2)*x(8) ...
    + Ytotal(1,3)*x(1) + Ytotal(1,3)*x(3) + Ytotal(3)*x(5) + Ytotal(1,3)*x(7) ...
    + Ytotal(1,4)*x(2) + Ytotal(1,4)*x(4) + Ytotal(4)*x(6) + Ytotal(1,4)*x(8));

eq = [totalSource1(timeSlot)/4,totalSource1(timeSlot)/4,totalSource1(timeSlot)/4,totalSource1(timeSlot)/4,...
    totalSource2(timeSlot)/4,totalSource2(timeSlot)/4,totalSource2(timeSlot)/4,totalSource2(timeSlot)/4,];
Equal = (sum(X) ...
    + Ytotal(1)*eq(1) + Ytotal(1)*eq(2) + Ytotal(1)*eq(5) + Ytotal(1)*eq(6) ...
    + Ytotal(2)*eq(3) + Ytotal(2)*eq(4) + Ytotal(2)*eq(7) + Ytotal(2)*eq(8) ...
    + Ytotal(3)*eq(1) + Ytotal(3)*eq(3) + Ytotal(3)*eq(5) + Ytotal(3)*eq(7) ...
    + Ytotal(4)*eq(2) + Ytotal(4)*eq(4) + Ytotal(4)*eq(6) + Ytotal(4)*eq(8));
%disp('Combined: ');
%disp(Answer);
%disp(Equal);
disp( (Equal - Answer)/Equal);



XElectricity = [0,0,0,0];

XElectricity(1,1) = x(9)*eStatic(1)*(ePrice1(timeSlot)*PUE(1) + 0*(WUE(1,1)+EWIF(1,1)*PUE(1,1))) - R(1,1)*(ePrice1(timeSlot)+0*EWIF(1));
XElectricity(1,2) = x(10)*eStatic(2)*(ePrice2(timeSlot)*PUE(2) + 0*(WUE(1,2)+EWIF(1,2)*PUE(1,2))) - R(1,2)*(ePrice2(timeSlot)+0*EWIF(2));
XElectricity(1,3) = x(11)*eStatic(3)*(ePrice3(timeSlot)*PUE(3) + 0*(WUE(1,3)+EWIF(1,3)*PUE(1,3))) - R(1,3)*(ePrice3(timeSlot)+0*EWIF(3));
XElectricity(1,4) = x(12)*eStatic(4)*(ePrice4(timeSlot)*PUE(4) + 0*(WUE(1,4)+EWIF(1,4)*PUE(1,4))) - R(1,4)*(ePrice4(timeSlot)+0*EWIF(4));
YElectricity = [0,0,0,0];
YElectricity(1) = compPower(1)*(ePrice1(timeSlot))/ (x(9)*serverCap(1));
YElectricity(2) = compPower(2)*(ePrice2(timeSlot))/ (x(10)*serverCap(2));
YElectricity(3) = compPower(3)*(ePrice3(timeSlot))/ (x(11)*serverCap(3));
YElectricity(4) = compPower(4)*(ePrice4(timeSlot))/ (x(12)*serverCap(4));
Answer = (sum(XElectricity)...
    + YElectricity(1,1)*x(1) + YElectricity(1,1)*x(2) + YElectricity(1,1)*x(5) + YElectricity(1,1)*x(6) ...
    + YElectricity(1,2)*x(3) + YElectricity(1,2)*x(4) + YElectricity(1,2)*x(7) + YElectricity(1,2)*x(8) ...
    + YElectricity(1,3)*x(1) + YElectricity(1,3)*x(3) + YElectricity(1,3)*x(5) + YElectricity(1,3)*x(7) ...
    + YElectricity(1,4)*x(2) + YElectricity(1,4)*x(4) + YElectricity(1,4)*x(6) + YElectricity(1,4)*x(8));
Equal = (sum(XElectricity) ...
    + YElectricity(1,1)*eq(1) + YElectricity(1,1)*eq(2) + YElectricity(1,1)*eq(5) + YElectricity(1,1)*eq(6) ...
    + YElectricity(1,2)*eq(3) + YElectricity(1,2)*eq(4) + YElectricity(1,2)*eq(7) + YElectricity(1,2)*eq(8) ...
    + YElectricity(1,3)*eq(1) + YElectricity(1,3)*eq(3) + YElectricity(1,3)*eq(5) + YElectricity(1,3)*eq(7) ...
    + YElectricity(1,4)*eq(2) + YElectricity(1,4)*eq(4) + YElectricity(1,4)*eq(6) + YElectricity(1,4)*eq(8));
%disp('Electricity: ');
%disp(Answer);
%disp(Equal);
disp( (Equal - Answer)/Equal);




%disp('Water: ');

XWater = [0,0,0,0];

XWater(1,1) = x(9)*eStatic(1)*(0*ePrice1(timeSlot)*PUE(1) + waterCoef*(WUE(1,1)+EWIF(1,1)*PUE(1,1))) - R(1,1)*(ePrice1(timeSlot)+waterCoef*EWIF(1));
XWater(1,2) = x(10)*eStatic(2)*(0*ePrice2(timeSlot)*PUE(2) + waterCoef*(WUE(1,2)+EWIF(1,2)*PUE(1,2))) - R(1,2)*(ePrice2(timeSlot)+waterCoef*EWIF(2));
XWater(1,3) = x(11)*eStatic(3)*(0*ePrice3(timeSlot)*PUE(3) + waterCoef*(WUE(1,3)+EWIF(1,3)*PUE(1,3))) - R(1,3)*(ePrice3(timeSlot)+waterCoef*EWIF(3));
XWater(1,4) = x(12)*eStatic(4)*(0*ePrice4(timeSlot)*PUE(4) + waterCoef*(WUE(1,4)+EWIF(1,4)*PUE(1,4))) - R(1,4)*(ePrice4(timeSlot)+waterCoef*EWIF(4));
YWater = [0,0,0,0];
YWater(1) = compPower(1)*(waterCoef*(WUE(1)+EWIF(1)*PUE(1))) / (x(9)*serverCap(1));
YWater(2) = compPower(2)*(waterCoef*(WUE(2)+EWIF(2)*PUE(2))) / (x(10)*serverCap(2));
YWater(3) = compPower(3)*(waterCoef*(WUE(3)+EWIF(3)*PUE(3))) / (x(11)*serverCap(3));
YWater(4) = compPower(4)*(waterCoef*(WUE(4)+EWIF(4)*PUE(4))) / (x(12)*serverCap(4));
Answer = (sum(XWater)...
    + YWater(1)*x(1) + YWater(1)*x(2) + YWater(1)*x(5) + YWater(1)*x(6) ...
    + YWater(2)*x(3) + YWater(2)*x(4) + YWater(2)*x(7) + YWater(2)*x(8) ...
    + YWater(3)*x(1) + YWater(3)*x(3) + YWater(3)*x(5) + YWater(3)*x(7) ...
    + YWater(4)*x(2) + YWater(4)*x(4) + YWater(4)*x(6) + YWater(4)*x(8));
Equal = (sum(XWater) ...
    + YWater(1)*eq(1) + YWater(1)*eq(2) + YWater(1)*eq(5) + YWater(1)*eq(6) ...
    + YWater(2)*eq(3) + YWater(2)*eq(4) + YWater(2)*eq(7) + YWater(2)*eq(8) ...
    + YWater(3)*eq(1) + YWater(3)*eq(3) + YWater(3)*eq(5) + YWater(3)*eq(7) ...
    + YWater(4)*eq(2) + YWater(4)*eq(4) + YWater(4)*eq(6) + YWater(4)*eq(8));
%disp(Answer);
%disp(Equal);
disp( (Equal - Answer)/Equal);

