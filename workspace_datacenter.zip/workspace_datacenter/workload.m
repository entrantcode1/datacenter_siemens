function [output] = workload(lambda, DCcap)
    output = roundn(10*lambda / DCcap, 0);
    if(output == 0)
        output = 1;
    end
    if(output > 8)
        output = 8;
    end
end