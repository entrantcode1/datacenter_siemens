function [c,ceq] = nlcon(x)
    ceq = [];
   
    timeSlot = 1;
    
    totalSource1 = 3.5*importdata('workloadSource1.mat');
    totalSource2 = 3.5*importdata('workloadSource2.mat');
    DCcap = [5,5,5,5];
    threshhold = 126;
    Data = importdata('AllData4.mat');
    sum=0;
    
    for a=1:threshhold
        sum = sum+Data(a,2,1,workload( (x(1)+x(2)+x(5)+x(6)),DCcap(1)));
    end
    P11 = sum;
    sum = 0;
        
    for a=1:threshhold
        sum = sum+Data(a,2,2,workload( (x(3)+x(4)+x(7)+x(8)),DCcap(2)));
    end
    P12 = sum;
    sum = 0;
    
    for a=1:threshhold
        sum = sum+Data(a,2,3,workload( (x(1)+x(3)+x(5)+x(7)),DCcap(3)));
    end
    P13 = sum;
    sum = 0;
    
    for a=1:threshhold
        sum = sum+Data(a,2,4,workload( (x(2)+x(4)+x(6)+x(8)),DCcap(4)));
    end
    P14 = sum;
    sum = 0;

    for a=1:threshhold
        sum = sum+Data(a,2,5,workload((x(1)+x(2)+x(5)+x(6)),DCcap(1)));
    end
    P21 = sum;
    sum = 0;
    
    for a=1:threshhold
        sum = sum+Data(a,2,6,workload((x(3)+x(4)+x(7)+x(8)),DCcap(2)));
    end
    P22 = sum;
    sum = 0;
    
    for a=1:threshhold
        sum = sum+Data(a,2,7,workload( (x(1)+x(3)+x(5)+x(7)),DCcap(3)));
    end
    P23 = sum;
    sum = 0;
    
    for a=1:threshhold
        sum = sum+Data(a,2,8,workload((x(2)+x(4)+x(6)+x(8)),DCcap(4)));
    end
    P24 = sum;
    
    x(1) = 0.95-(1.0/totalSource1(timeSlot))*(x(1)*P11*P13+x(2)*P11*P14+x(3)*P12*P13+x(4)*P12*P14);
    x(2) = 0.95-(1.0/totalSource2(timeSlot))*(x(5)*P21*P23+x(6)*P21*P24+x(7)*P22*P23+x(8)*P22*P24);
    
    c = [x(1), x(2)];
end